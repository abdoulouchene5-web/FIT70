FIT 70 — مشروع Android لتحويل تطبيق FIT 70 إلى APK

هذا مشروع Android Studio يحتوي على WebView يعرض نسخة FIT 70 محلياً داخل التطبيق.
لا يحتاج التطبيق إلى اتصال إنترنت بعد التثبيت، وتُحفظ بيانات التقدم في تخزين WebView المحلي على الجهاز.

إنشاء APK عبر Android Studio:
1. ثبّت Android Studio على الكمبيوتر.
2. فك ضغط FIT70_Android_Project.zip.
3. افتح المجلد FIT70_Android_Project في Android Studio.
4. وافق على تثبيت Android SDK 35 إذا طلب ذلك، وانتظر Gradle Sync.
5. من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6. ستجد APK في app/build/outputs/apk/debug/app-debug.apk.

إنشاء APK من الهاتف/دون Android Studio (باستخدام GitHub Actions):
1. أنشئ مستودع GitHub جديداً.
2. ارفع كل محتويات هذا المجلد إلى المستودع، بما فيها مجلد .github.
3. افتح تبويب Actions وشغّل Build FIT 70 APK.
4. بعد نجاح البناء، افتح نتيجة التشغيل ونزّل Artifact باسم FIT70-debug-apk؛ بداخله app-debug.apk.

ملاحظة:
- الملف الناتج Debug APK للتثبيت الشخصي، وليس إصداراً موقعاً للنشر في Google Play.
- يلزم بناء APK باستخدام Android SDK؛ بيئة الإنشاء الحالية لا تحتوي على Android SDK أو Gradle، لذلك أُرفق مشروع Android جاهزاً للبناء بدلاً من الادعاء بأن APK قد تم تجميعه.
