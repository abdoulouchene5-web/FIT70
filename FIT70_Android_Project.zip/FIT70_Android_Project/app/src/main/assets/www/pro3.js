(()=>{
const D={sl:'Sleep & mood|النوم والمزاج|Sonno e umore',hr:'Hours slept today|ساعات نومك اليوم|Ore dormite oggi',sv:'Save|حفظ|Salva',av:'avg sleep (7 days)|متوسط النوم (7 أيام)|sonno medio (7 giorni)',how:'How do you feel today?|كيف تشعر اليوم؟|Come ti senti oggi?',ph:'My food photos|صور طعامي|Le mie foto dei cibi',phd:'Pick a food, then take or choose a photo. It replaces the picture on its tile in the food diary.|اختر طعاماً ثم التقط أو اختر صورة لتحل محل صورته في سجل الطعام.|Scegli un cibo e una foto: sostituisce l’immagine nel diario.',pick:'Choose photo|اختر صورة|Scegli foto',rm:'Remove photo|حذف الصورة|Rimuovi foto'};
const L=k=>{const a=(D[k]||k).split('|');return a[{en:0,ar:1,it:2}[lang]||0]||a[0]};
const day=n=>{const d=new Date();d.setDate(d.getDate()-n);return d.toISOString().slice(0,10)};
const W=()=>load('fit70_well',{}),MOOD=['😞','😕','🙂','😄','🤩'];
const put=o=>{const w=W(),d=day(0);w[d]=Object.assign(w[d]||{},o);store('fit70_well',w);tools()};
window.pMood=m=>put({m});
window.pSleep=()=>{const s=+$('sIn').value;if(s>0&&s<=24)put({s})};
window.pPhoto=()=>{const f=$('pFl').files[0],id=$('pFd').value;if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas'),k=Math.min(1,360/Math.max(im.width,im.height));c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);try{store('fit70_photo_'+id,c.toDataURL('image/jpeg',.72))}catch(e){}window._pf=id;tools();if(window.pRefresh)pRefresh()};im.src=r.result};r.readAsDataURL(f)};
window.pRmPhoto=()=>{localStorage.removeItem('fit70_photo_'+$('pFd').value);tools();if(window.pRefresh)pRefresh()};
window.proExtra=()=>{
 const w=W(),t=w[day(0)]||{};let tot=0,n=0;const ds=[];
 for(let i=6;i>=0;i--){const x=w[day(i)]||{};ds.push([day(i),x]);if(x.s){tot+=x.s;n++}}
 const sleep=`<div class="card"><h2>💤 ${L('sl')}</h2><p class="muted">${L('how')}</p><div class="row" style="flex-wrap:nowrap;gap:6px">${MOOD.map((e,i)=>`<button onclick="pMood(${i+1})" style="font-size:26px;border:2px solid ${t.m===i+1?'var(--green)':'var(--line)'};background:var(--panel2);border-radius:14px;padding:8px 0;flex:1">${e}</button>`).join('')}</div><div class="row" style="flex-wrap:nowrap;margin-top:12px"><input id="sIn" type="number" step="0.5" min="0" max="24" placeholder="${L('hr')}" value="${t.s||''}" style="margin:0"><button class="btn" style="margin:0;flex:0 0 96px" onclick="pSleep()">${L('sv')}</button></div><div class="row" style="flex-wrap:nowrap;gap:5px;margin-top:14px;align-items:flex-end">${ds.map(([d,x])=>`<div style="text-align:center"><div style="height:56px;display:flex;align-items:flex-end"><i style="display:block;width:100%;height:${x.s?Math.min(100,x.s/10*100):3}%;background:${x.s&&x.s<6?'var(--red)':'var(--green)'};border-radius:6px 6px 0 0;opacity:${x.s?1:.25}"></i></div><div style="font-size:15px;min-height:20px">${x.m?MOOD[x.m-1]:''}</div><small class="muted">${d.slice(8)}</small></div>`).join('')}</div><p class="muted" style="margin:10px 0 0">😴 ${n?(tot/n).toFixed(1)+' h':'—'} ${L('av')}</p></div>`;
 const fl=(window.FIT_FOODS?FIT_FOODS():[]),sel=window._pf||(fl[0]&&fl[0].id),has=localStorage.getItem('fit70_photo_'+sel),ix={en:0,ar:1,it:2}[lang]||0;
 const photo=`<div class="card"><h2>📷 ${L('ph')}</h2><p class="muted">${L('phd')}</p><select id="pFd" onchange="window._pf=this.value;tools()">${fl.map(f=>`<option value="${f.id}" ${f.id===sel?'selected':''}>${f.e} ${f.n[ix]}</option>`).join('')}</select>${has?`<img src="${JSON.parse(has)}" alt="" style="width:100%;max-height:160px;object-fit:cover;border-radius:12px;margin-bottom:8px">`:''}<input id="pFl" type="file" accept="image/*" onchange="pPhoto()" style="padding:9px">${has?`<button class="btn danger" onclick="pRmPhoto()">${L('rm')}</button>`:''}</div>`;
 return sleep+photo;
};
tools();
})();
