(()=>{
const P={
en:{pro:'Pro',al:'Alarm center',ald:'One alarm for every meal and one for your workout. The workout alarm rings only on your training days.',save:'Save all alarms',ok:'Alarms saved.',nn:'Open the installed Android app to enable alarms.',bf:'Breakfast',sn1:'Morning snack',lu:'Lunch',sn2:'Afternoon snack',di:'Dinner',eat:'Time to eat',go:'Time to train',lg:'Food diary',left:'kcal left',over:'kcal over',pr:'Protein',ca:'Carbs',fa:'Fat',tap:'Tap a food to add it to today',rt:'Rest timer',dn:'Mark today’s workout as done',un:'Workout done ✓ (tap to undo)',st:'day streak',bd:'Badges',wt:'Weight trend',nw:'Log two weights to see the chart.',sec:'sec'},
ar:{pro:'برو',al:'مركز التنبيهات',ald:'تنبيه لكل وجبة وتنبيه واحد للتمرين. تنبيه التمرين يعمل في أيام التدريب فقط.',save:'حفظ كل التنبيهات',ok:'تم حفظ التنبيهات.',nn:'افتح تطبيق أندرويد المثبت لتفعيل التنبيهات.',bf:'الفطور',sn1:'وجبة خفيفة صباحاً',lu:'الغداء',sn2:'وجبة خفيفة عصراً',di:'العشاء',eat:'حان وقت الأكل',go:'حان وقت التمرين',lg:'سجل الطعام',left:'سعرة متبقية',over:'سعرة زائدة',pr:'بروتين',ca:'كربوهيدرات',fa:'دهون',tap:'اضغط على طعام لإضافته إلى اليوم',rt:'مؤقت الراحة',dn:'تم تمرين اليوم',un:'تم التمرين ✓ (اضغط للتراجع)',st:'أيام متتالية',bd:'الأوسمة',wt:'منحنى الوزن',nw:'سجّل وزنين لإظهار المنحنى.',sec:'ث'},
it:{pro:'Pro',al:'Centro sveglie',ald:'Una sveglia per ogni pasto e una per l’allenamento. Suona solo nei giorni di allenamento.',save:'Salva tutte le sveglie',ok:'Sveglie salvate.',nn:'Apri l’app Android installata per attivare le sveglie.',bf:'Colazione',sn1:'Spuntino mattina',lu:'Pranzo',sn2:'Spuntino pomeriggio',di:'Cena',eat:'È ora di mangiare',go:'È ora di allenarsi',lg:'Diario alimentare',left:'kcal rimaste',over:'kcal in più',pr:'Proteine',ca:'Carboidrati',fa:'Grassi',tap:'Tocca un cibo per aggiungerlo a oggi',rt:'Timer di recupero',dn:'Segna allenamento fatto',un:'Allenamento fatto ✓ (tocca per annullare)',st:'giorni di fila',bd:'Medaglie',wt:'Andamento peso',nw:'Registra due pesi per vedere il grafico.',sec:'s'}};
const L=k=>(P[lang]||P.en)[k]||P.en[k];
const FOODS=[
['egg','🍳',40,160,13,1,11,'2 eggs|بيضتان|2 uova'],['oat','🥣',35,320,10,58,5,'Banana oats|شوفان بالموز|Avena e banana'],
['yog','🥛',200,150,15,8,5,'Greek yogurt|لبن يوناني|Yogurt greco'],['chk','🍗',20,250,40,0,8,'Grilled chicken|دجاج مشوي|Pollo alla griglia'],
['ric','🍚',50,205,4,45,0,'Rice (1 cup)|أرز (كوب)|Riso (1 tazza)'],['sal','🥗',130,120,3,10,8,'Big salad|سلطة كبيرة|Insalatona'],
['fsh','🐟',210,220,30,0,10,'Fish fillet|فيليه سمك|Filetto di pesce'],['bean','🫘',25,300,18,50,1,'Bean bowl|طبق فاصوليا|Piatto di fagioli'],
['pas','🍝',15,350,12,70,2,'Pasta plate|طبق معكرونة|Piatto di pasta'],['brd','🍞',30,160,8,28,2,'Whole-grain toast|توست كامل الحبوب|Toast integrale'],
['fru','🍎',0,80,0,20,0,'Fruit|فاكهة|Frutta'],['nut','🥜',45,180,6,6,16,'Handful of nuts|حفنة مكسرات|Manciata di noci'],
['tun','🥪',190,340,25,36,10,'Tuna sandwich|ساندويتش تونة|Panino al tonno'],['shk','🥤',160,160,25,6,3,'Protein shake|مشروب بروتين|Frullato proteico']
].map(a=>{const f={id:a[0],e:a[1],h:a[2],k:a[3],p:a[4],c:a[5],f:a[6],n:a[7].split('|')};
f.a='data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 90"><defs><radialGradient id="g"><stop offset="0" stop-color="hsl(${f.h},75%,60%)"/><stop offset="1" stop-color="hsl(${f.h},60%,20%)"/></radialGradient></defs><rect width="120" height="90" fill="url(#g)"/><ellipse cx="60" cy="70" rx="40" ry="8" fill="#0006"/><circle cx="60" cy="46" r="31" fill="#ffffff26"/><circle cx="60" cy="46" r="24" fill="#ffffff22"/><text x="60" y="59" font-size="36" text-anchor="middle">${f.e}</text></svg>`);return f});
window.FIT_FOODS=()=>FOODS.concat(load('fit70_custom',[]));
window.FIT_FOOD=id=>FOODS.find(f=>f.id===id)||load('fit70_custom',[]).find(f=>f.id===id)||(String(id).startsWith('m|')?(a=>({id,e:a[3],k:+a[1],p:+a[2],c:0,f:0,n:[a[4],a[4],a[4]],a:''}))(id.split('|')):undefined);
const fname=f=>f.n[lang==='ar'?1:lang==='it'?2:0];
const today=()=>new Date().toISOString().slice(0,10),pad=n=>String(n).padStart(2,'0');
function items(){
 const g=(workoutPlace||'gym')==='gym',ks=g?['legpress','press','pulldown','hinge','plank']:['squat','push','row','bridge','lunge','plank'];
 const w=(load('fit70_reminders',{}).workout||'18:00').split(':').map(Number),at=m=>{const t=w[0]*60+w[1]+m;return pad(Math.floor(t/60)%24)+':'+pad(t%60)};
 const td=[[0,3],[0,2,4],[0,1,3,5],[0,1,2,4,5],[0,1,2,3,4,5]][(profile.days||3)-2]||[0,2,4];
 const xm=td.reduce((s,d)=>s|1<<((d+1)%7),0);
 return [['bf','08:00'],['sn1','11:00'],['lu','13:00'],['sn2','16:30'],['di','19:30']].map(([k,t])=>({id:'a_'+k,label:L(k),t,mask:127,e:'🍽️',msg:L('eat')}))
 .concat([{id:'x_workout',label:tr('train'),t:at(0),mask:xm,e:'💪',msg:L('go')}]);
}
const OLDX=['legpress','press','pulldown','hinge','plank','squat','push','row','bridge','lunge'];function oldAl(){const N=window.FIT70Native;if(N&&N.cancel)OLDX.forEach(k=>N.cancel('x_'+k))}
try{if(!localStorage.getItem('fit70_m9')){oldAl();localStorage.setItem('fit70_m9','1')}}catch(e){}
function renderA(){
 const st=load('fit70_alarms',{});
 $('pA').innerHTML=`<div class="card"><h2>⏰ ${L('al')}</h2><p class="muted">${L('ald')}</p>`+items().map(it=>{const s=st[it.id]||{};return `<label class="choice"><input type="checkbox" id="on_${it.id}" ${s.on===false?'':'checked'}><span class="emoji" style="font-size:18px">${it.e}</span><span style="flex:1">${it.label}</span><input type="time" data-a="${it.id}" value="${s.t||it.t}" style="width:112px;margin:0"></label>`}).join('')+`<button class="btn" onclick="pSave()">${L('save')}</button><p class="muted" id="pAs"></p></div>`;
}
window.pSave=()=>{oldAl();
 const st={},N=window.FIT70Native;let ok=0;
 const list=items();
 list.forEach(it=>{const t=$('pA').querySelector(`[data-a="${it.id}"]`).value||it.t,on=$('on_'+it.id).checked;st[it.id]={t,on};
  if(N&&N.scheduleAt){if(on){const a=t.split(':').map(Number);if(N.scheduleAt(it.id,a[0],a[1],it.mask,it.label,it.msg))ok++}else N.cancel(it.id)}});
 store('fit70_alarms',st);
 if(N&&N.canExact&&!N.canExact())N.openExactSettings();
 $('pAs').textContent=N&&N.scheduleAt?L('ok'):L('nn');
};
function streak(){const d=load('fit70_done',[]);let n=0,t=new Date();if(!d.includes(t.toISOString().slice(0,10)))t.setDate(t.getDate()-1);while(d.includes(t.toISOString().slice(0,10))){n++;t.setDate(t.getDate()-1)}return n}
const mb=(l,v,t)=>`<small class="muted">${l}: ${Math.round(v)} / ${t} g</small><div class="bar"><i style="width:${Math.min(100,v/Math.max(1,t)*100)}%"></i></div>`;
function renderB(){
 const c=calc(profile),lg=load('fit70_log_'+today(),[]),F=window.FIT_FOOD;
 let k=0,p=0,cb=0,ft=0;lg.forEach(id=>{const f=F(id);if(f){k+=f.k;p+=f.p;cb+=f.c;ft+=f.f}});
 const fT=Math.round(c.kcal*.25/9),cT=Math.max(0,Math.round((c.kcal-c.protein*4-fT*9)/4)),d=Math.min(1,k/c.kcal)*251.3,rem=c.kcal-k;
 const s=streak(),done=load('fit70_done',[]).includes(today()),water=load('fit70_water_'+today(),0);
 const bg=[['🔥',s>=3,'3'],['⚡',s>=7,'7'],['🏆',s>=30,'30'],['⚖️',entries.length>0,''],['💧',water>=8,'8'],['🍽️',lg.length>=3,'3']].map(b=>`<span class="pill" style="font-size:20px;opacity:${b[1]?1:.25}">${b[0]}<small style="font-size:10px"> ${b[2]}</small></span>`).join(' ');
 let ch='';if(entries.length>1){const v=entries.map(e=>+e.weight),mn=Math.min(...v),r=Math.max(...v)-mn||1;ch=`<svg viewBox="0 0 300 80" width="100%"><polyline points="${v.map((y,i)=>`${(i*300/(v.length-1)).toFixed(1)},${(72-(y-mn)/r*62).toFixed(1)}`).join(' ')}" fill="none" stroke="var(--green)" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/></svg>`}else ch=`<p class="muted">${L('nw')}</p>`;
 $('pB').innerHTML=`<div class="card"><h2>🍽️ ${L('lg')}</h2><div class="row" style="flex-wrap:nowrap"><svg viewBox="0 0 100 100" width="128" style="flex:0 0 128px"><circle cx="50" cy="50" r="40" fill="none" stroke="#293b51" stroke-width="10"/><circle cx="50" cy="50" r="40" fill="none" stroke="${rem<0?'#ff9b9b':'var(--green)'}" stroke-width="10" stroke-linecap="round" stroke-dasharray="${d} 251.3" transform="rotate(-90 50 50)"/><text x="50" y="49" text-anchor="middle" fill="currentColor" font-size="17" font-weight="800">${k}</text><text x="50" y="63" text-anchor="middle" fill="#aab4c0" font-size="8">/ ${c.kcal} kcal</text></svg><div style="flex:1">${mb(L('pr'),p,c.protein)}${mb(L('ca'),cb,cT)}${mb(L('fa'),ft,fT)}<p class="muted" style="margin:8px 0 0">${Math.abs(rem)} ${rem<0?L('over'):L('left')}</p></div></div><p class="muted">${L('tap')}</p><div class="grid2">${FOODS.concat(load('fit70_custom',[])).map(f=>`<button class="tile" onclick="pAdd('${f.id}')" style="border:1px solid var(--line);color:var(--text);text-align:start"><img src="${load('fit70_photo_'+f.id,'')||'img/food-'+f.id+'.jpg'}" onerror="this.onerror=null;this.src='${f.a}'" alt="" style="width:100%;height:74px;object-fit:cover;border-radius:10px"><b style="font-size:12px;display:block;margin-top:5px">${fname(f)}</b><small class="muted">${f.k} kcal · ${f.p} g</small></button>`).join('')}</div><div class="history" style="margin-top:12px">${lg.map((id,i)=>{const f=F(id);return f?`<div class="entry"><span>${f.e} ${fname(f)}</span><span>${f.k} kcal <a href="#" onclick="pDel(${i});return false" style="color:var(--red);margin-inline-start:8px">✕</a></span></div>`:''}).join('')}</div></div>
 <div class="card"><h2>⏱️ ${L('rt')}</h2><div class="stat" style="text-align:center"><b id="tmv" style="font-size:38px">0</b><small>${L('sec')}</small></div><div class="grid3" style="margin-top:8px">${[30,60,90].map(s=>`<button class="btn secondary" onclick="pRest(${s})">${s}</button>`).join('')}</div><button class="btn ${done?'secondary':''}" onclick="pDone()">${done?L('un'):L('dn')}</button></div>
 <div class="card"><h2>🔥 ${s} ${L('st')}</h2><h3>${L('bd')}</h3><div class="row" style="gap:6px">${bg}</div></div>
 <div class="card"><h2>📈 ${L('wt')}</h2>${ch}</div>`;
}
window.pRefresh=()=>renderB();window.pAdd=id=>{const k='fit70_log_'+today(),l=load(k,[]);l.push(id);store(k,l);renderB()};
window.pDel=i=>{const k='fit70_log_'+today(),l=load(k,[]);l.splice(i,1);store(k,l);renderB()};
window.pDone=()=>{let d=load('fit70_done',[]);const t=today();d=d.includes(t)?d.filter(x=>x!==t):d.concat(t);store('fit70_done',d);renderB()};
let tm=null;
window.pRest=s=>{clearInterval(tm);let n=s;$('tmv').textContent=n;tm=setInterval(()=>{n--;const o=$('tmv');if(o)o.textContent=Math.max(0,n);if(n<=0){clearInterval(tm);try{const a=new AudioContext(),o2=a.createOscillator();o2.connect(a.destination);o2.frequency.value=880;o2.start();setTimeout(()=>o2.stop(),600)}catch(e){}if(navigator.vibrate)navigator.vibrate([300,150,300])}},1000)};
function render(){
 const pl=$('plus');if(!pl)return;$('proTab').textContent='⭐ '+L('pro');
 if(!profile)return;
 if(!$('pA'))pl.innerHTML='<div id="pA"></div><div id="pB"></div>';
 renderA();renderB();
}
const a0=applyLang;applyLang=function(){a0();render()};
const r0=renderAll;renderAll=function(){r0();render()};
$('placeSwitch').addEventListener('change',render);
render();
})();
