package com.fit70.app;
import android.content.*;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) { Alarms.restore(c); }
}
