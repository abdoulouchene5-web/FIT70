package com.fit70.app;
import android.app.NotificationManager;
import android.content.*;

/** Handles the "I drank" and "In 15 min" buttons on the water notification. */
public class ActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(i.getIntExtra("nid", 0));
        if ("DRANK".equals(i.getAction())) {
            SharedPreferences p = c.getSharedPreferences("water", 0);
            p.edit().putInt("n", p.getInt("n", 0) + 1).apply();
        } else if ("LATER".equals(i.getAction())) {
            Alarms.once(c, "w_later", System.currentTimeMillis() + 15 * 60 * 1000L, i.getStringExtra("title"), i.getStringExtra("message"));
        }
    }
}
