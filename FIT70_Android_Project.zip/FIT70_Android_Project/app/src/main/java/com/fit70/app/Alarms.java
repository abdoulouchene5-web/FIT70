package com.fit70.app;
import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import java.util.Calendar;
import java.util.Map;

/** Exact, weekday-aware alarms that survive reboots (re-armed by BootReceiver). */
public class Alarms {
    static final String CH = "fit70_alarm2";

    static void channel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel ch = new NotificationChannel(CH, "FIT70 alarms", NotificationManager.IMPORTANCE_HIGH);
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 400, 200, 400});
        ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }

    static boolean set(Context c, String id, int h, int m, int mask, String title, String msg) {
        if (h < 0 || h > 23 || m < 0 || m > 59 || mask <= 0) return false;
        c.getSharedPreferences("alarms", 0).edit()
                .putString(id, h + "|" + m + "|" + mask + "|" + title.replace("|", " ") + "|" + msg.replace("|", " ")).apply();
        arm(c, id, h, m, mask, title, msg);
        return true;
    }

    static void arm(Context c, String id, int h, int m, int mask, String title, String msg) {
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, h); t.set(Calendar.MINUTE, m); t.set(Calendar.SECOND, 0); t.set(Calendar.MILLISECOND, 0);
        for (int i = 0; i < 8; i++) {
            boolean dayOk = (mask & (1 << (t.get(Calendar.DAY_OF_WEEK) - 1))) != 0;
            if (dayOk && t.getTimeInMillis() > System.currentTimeMillis() + 1000) break;
            t.add(Calendar.DAY_OF_YEAR, 1);
        }
        Intent in = new Intent(c, ReminderReceiver.class).putExtra("id", id).putExtra("h", h).putExtra("m", m)
                .putExtra("mask", mask).putExtra("title", title).putExtra("message", msg);
        PendingIntent pi = PendingIntent.getBroadcast(c, id.hashCode(), in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pi);
        else
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pi);
    }

    /** One-shot exact alarm at an epoch time (used for the fasting-end alarm). */
    static boolean once(Context c, String id, long at, String title, String msg) {
        if (at <= System.currentTimeMillis()) return false;
        Intent in = new Intent(c, ReminderReceiver.class).putExtra("id", id).putExtra("mask", 0)
                .putExtra("title", title).putExtra("message", msg);
        PendingIntent pi = PendingIntent.getBroadcast(c, id.hashCode(), in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        return true;
    }

    static void cancel(Context c, String id) {
        c.getSharedPreferences("alarms", 0).edit().remove(id).apply();
        PendingIntent pi = PendingIntent.getBroadcast(c, id.hashCode(), new Intent(c, ReminderReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);
    }

    static void restore(Context c) {
        for (Map.Entry<String, ?> e : c.getSharedPreferences("alarms", 0).getAll().entrySet()) {
            String[] p = ((String) e.getValue()).split("\\|");
            if (p.length >= 5) arm(c, e.getKey(), Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]), p[3], p[4]);
        }
    }
}
