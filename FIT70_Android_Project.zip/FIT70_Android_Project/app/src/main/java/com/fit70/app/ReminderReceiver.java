package com.fit70.app;
import android.app.*;
import android.content.*;
import android.media.RingtoneManager;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    static PendingIntent act(Context c, String a, int nid, String title, String msg) {
        Intent i = new Intent(c, ActionReceiver.class).setAction(a).putExtra("nid", nid).putExtra("title", title).putExtra("message", msg);
        return PendingIntent.getBroadcast(c, nid * 2 + (a.equals("DRANK") ? 0 : 1), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    @Override public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title"), message = intent.getStringExtra("message"), id = intent.getStringExtra("id");
        String[] parts = (message == null ? "" : message).split("\u2016");
        String text = parts.length > 0 && !parts[0].isEmpty() ? parts[0] : "Time for your plan";
        int nid = (int) (System.currentTimeMillis() % 100000);
        PendingIntent content = PendingIntent.getActivity(context, 0, new Intent(context, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String ch = id != null ? Alarms.CH : "fit70_daily";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, ch) : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title == null ? "FIT70" : title).setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(content).setCategory(Notification.CATEGORY_ALARM);
        if (id != null && id.startsWith("w_") && parts.length >= 3) {
            b.addAction(android.R.drawable.checkbox_on_background, parts[1], act(context, "DRANK", nid, title, message));
            b.addAction(android.R.drawable.ic_popup_reminder, parts[2], act(context, "LATER", nid, title, message));
        }
        if (Build.VERSION.SDK_INT < 26 && id != null)
            b.setPriority(Notification.PRIORITY_HIGH).setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)).setVibrate(new long[]{0, 400, 200, 400});
        ((NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(nid, b.build());
        if (id != null && intent.getIntExtra("mask", 127) > 0) Alarms.arm(context, id, intent.getIntExtra("h", 0), intent.getIntExtra("m", 0), intent.getIntExtra("mask", 127),
                title == null ? "FIT70" : title, message == null ? "" : message);
    }
}
