package com.fit70.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context, Intent intent) {
  String title=intent.getStringExtra("title"); String message=intent.getStringExtra("message");
  Intent open=new Intent(context,MainActivity.class);
  PendingIntent content=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder builder;
  if(Build.VERSION.SDK_INT>=26) builder=new Notification.Builder(context,"fit70_daily"); else builder=new Notification.Builder(context);
  builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title==null?"FIT70":title).setContentText(message==null?"Time for your plan":message).setAutoCancel(true).setContentIntent(content);
  ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000),builder.build());
 }
}
