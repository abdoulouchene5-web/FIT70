package com.fit70.app;
import android.app.*;
import android.content.*;
import android.media.RingtoneManager;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title"), message = intent.getStringExtra("message"), id = intent.getStringExtra("id");
        PendingIntent content = PendingIntent.getActivity(context, 0, new Intent(context, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String ch = id != null ? Alarms.CH : "fit70_daily";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, ch) : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title == null ? "FIT70" : title)
                .setContentText(message == null ? "Time for your plan" : message).setAutoCancel(true)
                .setContentIntent(content).setCategory(Notification.CATEGORY_ALARM);
        if (Build.VERSION.SDK_INT < 26 && id != null)
            b.setPriority(Notification.PRIORITY_HIGH).setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)).setVibrate(new long[]{0, 400, 200, 400});
        ((NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int) (System.currentTimeMillis() % 100000), b.build());
        if (id != null && intent.getIntExtra("mask", 127) > 0) Alarms.arm(context, id, intent.getIntExtra("h", 0), intent.getIntExtra("m", 0), intent.getIntExtra("mask", 127),
                title == null ? "FIT70" : title, message == null ? "" : message);
    }
}
