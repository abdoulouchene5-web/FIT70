package com.fit70.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
import java.util.Calendar;

public class MainActivity extends Activity {
    private WebView webView;
    private android.webkit.ValueCallback<android.net.Uri[]> filePathCallback;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(20, 17, 12));
        getWindow().setNavigationBarColor(Color.rgb(8, 13, 20));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS, WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        createChannel(); Alarms.channel(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 13, 20));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setDatabaseEnabled(true);
        webView.addJavascriptInterface(new FitBridge(this), "FIT70Native");
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, android.webkit.ValueCallback<android.net.Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
                try { startActivityForResult(Intent.createChooser(i, "Photo"), 71); } catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        root.setBackgroundColor(0xFF0B1422);
        root.addView(webView, new android.widget.FrameLayout.LayoutParams(-1, -1));
        root.setOnApplyWindowInsetsListener((v, ins) -> { v.setPadding(ins.getSystemWindowInsetLeft(), ins.getSystemWindowInsetTop(), ins.getSystemWindowInsetRight(), ins.getSystemWindowInsetBottom()); return ins; });
        setContentView(root); webView.loadUrl("file:///android_asset/www/index.html");
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("fit70_daily", "FIT70 reminders", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Meal, workout and hydration reminders");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }
    static class FitBridge {
        private final Activity activity;
        private static boolean permissionRequestStarted = false;
        FitBridge(Activity a) { activity = a; }
        @JavascriptInterface public boolean scheduleDaily(String id, int hour, int minute, String title, String message) {
            if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return false;
            return schedule(id, title, message, hour, minute, 24 * 60 * 60 * 1000L);
        }
        @JavascriptInterface public boolean scheduleInterval(String id, int minutes, String message) {
            if (minutes < 30 || minutes > 240) return false;
            return schedule(id, "FIT70", message, -1, -1, minutes * 60 * 1000L);
        }
        boolean stepReg, stepAsked; float stepTotal = -1;
        @JavascriptInterface public String steps() {
            if (Build.VERSION.SDK_INT >= 29 && activity.checkSelfPermission("android.permission.ACTIVITY_RECOGNITION") != PackageManager.PERMISSION_GRANTED) {
                if (!stepAsked) { stepAsked = true; activity.runOnUiThread(() -> activity.requestPermissions(new String[]{"android.permission.ACTIVITY_RECOGNITION"}, 72)); }
                return "-1";
            }
            if (!stepReg) {
                android.hardware.SensorManager sm = (android.hardware.SensorManager) activity.getSystemService(Context.SENSOR_SERVICE);
                android.hardware.Sensor sen = sm.getDefaultSensor(android.hardware.Sensor.TYPE_STEP_COUNTER);
                if (sen == null) return "-2";
                stepReg = sm.registerListener(new android.hardware.SensorEventListener() {
                    public void onSensorChanged(android.hardware.SensorEvent e) { stepTotal = e.values[0]; }
                    public void onAccuracyChanged(android.hardware.Sensor s, int a) {}
                }, sen, android.hardware.SensorManager.SENSOR_DELAY_UI);
            }
            return String.valueOf(stepTotal);
        }
        @JavascriptInterface public void shareText(String text) {
            activity.runOnUiThread(() -> { Intent i = new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, text); activity.startActivity(Intent.createChooser(i, "FIT70")); });
        }
        @JavascriptInterface public boolean scheduleAt(String id, int hour, int minute, int mask, String title, String message) { askPerm(); return Alarms.set(activity, id, hour, minute, mask, title, message); }
        @JavascriptInterface public boolean scheduleOnce(String id, String atMillis, String title, String message) { askPerm(); try { return Alarms.once(activity, id, Long.parseLong(atMillis), title, message); } catch (Exception e) { return false; } }
        @JavascriptInterface public void cancel(String id) { Alarms.cancel(activity, id); }
        @JavascriptInterface public boolean canExact() { if (Build.VERSION.SDK_INT < 31) return true; return ((AlarmManager)activity.getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms(); }
        @JavascriptInterface public void openExactSettings() { if (Build.VERSION.SDK_INT >= 31) activity.runOnUiThread(() -> activity.startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse("package:" + activity.getPackageName())))); }
        private void askPerm() { if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !permissionRequestStarted) { permissionRequestStarted = true; activity.runOnUiThread(() -> activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 70)); } }
        private boolean schedule(String id, String title, String message, int hour, int minute, long interval) {
            if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !permissionRequestStarted) {
                permissionRequestStarted = true;
                activity.runOnUiThread(() -> activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 70));
            }
            Intent intent = new Intent(activity, ReminderReceiver.class);
            intent.putExtra("title", title); intent.putExtra("message", message);
            int requestCode = id.hashCode();
            PendingIntent pi = PendingIntent.getBroadcast(activity, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager)activity.getSystemService(Context.ALARM_SERVICE);
            long first;
            if (hour >= 0) {
                Calendar c = Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
                if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);
                first = c.getTimeInMillis();
            } else first = System.currentTimeMillis() + interval;
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, first, interval, pi);
            return true;
        }
    }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == 71 && filePathCallback != null) {
            android.net.Uri[] r = (res == RESULT_OK && data != null && data.getData() != null) ? new android.net.Uri[]{data.getData()} : null;
            filePathCallback.onReceiveValue(r); filePathCallback = null;
        } else super.onActivityResult(req, res, data);
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
