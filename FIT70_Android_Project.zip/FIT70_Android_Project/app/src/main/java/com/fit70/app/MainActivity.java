package com.fit70.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
import java.util.Calendar;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(20, 17, 12));
        getWindow().setNavigationBarColor(Color.rgb(8, 13, 20));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS, WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        createChannel();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 13, 20));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setDatabaseEnabled(true);
        webView.addJavascriptInterface(new FitBridge(this), "FIT70Native");
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView); webView.loadUrl("file:///android_asset/www/index.html");
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("fit70_daily", "FIT70 reminders", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Meal, workout and hydration reminders");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }
    static class FitBridge {
        private final Activity activity;
        private static boolean permissionRequestStarted = false;
        FitBridge(Activity a) { activity = a; }
        @JavascriptInterface public boolean scheduleDaily(String id, int hour, int minute, String title, String message) {
            if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return false;
            return schedule(id, title, message, hour, minute, 24 * 60 * 60 * 1000L);
        }
        @JavascriptInterface public boolean scheduleInterval(String id, int minutes, String message) {
            if (minutes < 30 || minutes > 240) return false;
            return schedule(id, "FIT70", message, -1, -1, minutes * 60 * 1000L);
        }
        private boolean schedule(String id, String title, String message, int hour, int minute, long interval) {
            if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !permissionRequestStarted) {
                permissionRequestStarted = true;
                activity.runOnUiThread(() -> activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 70));
            }
            Intent intent = new Intent(activity, ReminderReceiver.class);
            intent.putExtra("title", title); intent.putExtra("message", message);
            int requestCode = id.hashCode();
            PendingIntent pi = PendingIntent.getBroadcast(activity, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager)activity.getSystemService(Context.ALARM_SERVICE);
            long first;
            if (hour >= 0) {
                Calendar c = Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
                if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);
                first = c.getTimeInMillis();
            } else first = System.currentTimeMillis() + interval;
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, first, interval, pi);
            return true;
        }
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
