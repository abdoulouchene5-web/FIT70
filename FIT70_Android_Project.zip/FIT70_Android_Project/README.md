# FIT70 7.0

Fitness, nutrition and workout planner for Android (EN / AR / IT). A web app (`app/src/main/assets/www`) inside a native Android shell.

## Single-zip method (phone friendly)
Upload `FIT70_Android_Project.zip` as-is to the root of a repo whose workflow unzips it, replacing the old zip. The project sits inside a `FIT70_Android_Project/` folder.

## Build the APK with GitHub (no computer tools needed)
1. Create a GitHub repository, then upload **the contents** of this zip (not the zip itself) so `.github/` and `app/` are at the repo root.
2. Open **Actions → Build FIT70 APK → Run workflow** (it also runs on every push to `main`).
3. When it turns green, open the run and download the artifact **FIT70-debug-apk**, unzip it and install `app-debug.apk`.

Local build: Java 17 + Android SDK + Gradle 8.9, then `gradle assembleDebug`.

## What's new in 7.0
- **Fasting-end alarm**: starting a fast schedules an exact alarm for when it completes; ending the fast cancels it.
- **My food photos**: Tools tab, pick a food, take or choose a photo; it replaces that tile's picture in the food diary (included in backups).
- **Sleep & mood tracker** with a 7-day chart and average sleep.
- **App icon** added. A real grilled-chicken photo ships for the chicken tile.

## What's new in 6.0
- **Professional look**: refined glass tab bar, gradient buttons, safe-area support, **light and dark themes**, 5 accent colours.
- **🧰 Tools tab**: weekly report with 7-day calorie chart and estimated goal date; workout log with personal records; intermittent-fasting timer (12-20 h); body measurements with change tracking; your own custom foods; backup and restore as text.

## Also in 5.0
- **Pro tab**: a separate alarm for every meal (5) and every exercise, with on/off and time. Exercise alarms ring only on training days.
- Exact alarms (alarm sound, vibration), re-armed after reboot, app update or timezone change. On Android 12+ allow "Alarms & reminders" when asked.
- Food diary with 14 foods, photo tiles, calorie ring and protein/carbs/fat targets.
- Rest timer (30/60/90 s) with beep and vibration, workout streak, badges, weight trend chart.

## Real food photos
Tiles use illustrated art by default. To use real photos, add JPGs named `app/src/main/assets/www/img/food-<id>.jpg` (ids: egg, oat, yog, chk, ric, sal, fsh, bean, pas, brd, fru, nut, tun, shk). They are picked up automatically.

## Notes
Estimates are educational, not medical advice. Debug APK is for personal install, not Google Play.

---
# FIT70 5.0 (عربي)
1. أنشئ مستودعاً على GitHub وارفع **محتويات** الملف المضغوط (وليس الملف نفسه).
2. من تبويب Actions شغّل Build FIT70 APK.
3. نزّل FIT70-debug-apk وثبّت app-debug.apk.
تبويب **Pro**: تنبيه لكل وجبة ولكل تمرين، سجل طعام بصور، مؤقت راحة، سلسلة أيام، أوسمة ومنحنى وزن.
