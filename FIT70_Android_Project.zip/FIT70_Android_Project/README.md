# FIT70 8.5

Fitness, nutrition and workout planner for Android (EN / AR / IT). A web app (`app/src/main/assets/www`) inside a native Android shell.

## What's new in 8.5
- **Serious notifications** (set automatically after setup, editable in Pro > Alarm center): meals, workout, **6 water reminders with "I drank" / "In 15 min" buttons**, bedtime, daily mood check, weekly weigh-in, shopping day.
- **Mood** card on Home. **I ate something different**: enter ingredients (or your own kcal values), see calories and protein, add to your diary.
- **Pantry**: icon button inside Meals; meals only from what you have by default; **low-stock alerts** (notification before an item runs out) and finished items go to the shopping list automatically; **Next week** shopping list from your budget and what is left.
- Empty age/height/weight fields at first start; smoother, more realistic exercise animations.

## What's new in 8.4
- **Exercise library**: 20 exercises for gym, home and **street workout** (pull-ups, dips, muscle-ups, L-sit, pistol squats, burpees...), each with an **animated illustration** drawn inside the app. Three levels (beginner / intermediate / advanced) change sets and reps.
- **Workout session**: press Start on today's card, tick every exercise you finish, then Finish: you get a **summary with time spent and calories burned** (per exercise, using MET x your weight x time). Saved in a history and added to the Home burn counter.
- 5 more recipes and 8 more groceries (bulgur, ricotta, turkey, borlotti beans, sardines, aubergine, spinach, onions).

## What's new in 8.3
- **Pantry / inventory**: in your first week the app asks if you have groceries at home and lets you pick them with quantities (eggs in pieces). With "Cook only with what I have" on, meals are only dishes you can cook from your pantry; eating a dish subtracts its ingredients (6 eggs, ate 2 = 4 left). Dishes you cannot cook show what is missing.
- **Shopping list = what you still need to buy.** Tick an item when you buy it and it moves into your pantry.
- **Calories burned counter** on Home: steps (weight-based) + workout (MET 5 x weight x minutes, 30/45/60/90), with net calories (eaten minus burned).

## What's new in 8.2
- **Goal period**: choose in how many weeks you want to reach your goal weight (4-52). The calorie target comes from it, capped for safety, with a warning and the safe number of weeks if the goal is too aggressive.
- **New home**: calorie ring, streak, goal journey (on track / behind), next meal and today's workout, quick actions, steps (phone sensor only), tap-to-fill water glasses, tip of the day.
- **One workout alarm** instead of one per exercise (old per-exercise alarms are cancelled automatically).
- Orange **I ate this** button, **swap dish** on every meal, page, card, bar and ring animations.

## Single-zip method (phone friendly)
Upload `FIT70_Android_Project.zip` as-is to the root of a repo whose workflow unzips it, replacing the old zip. The project sits inside a `FIT70_Android_Project/` folder.

## Build the APK with GitHub (no computer tools needed)
1. Create a GitHub repository, then upload **the contents** of this zip (not the zip itself) so `.github/` and `app/` are at the repo root.
2. Open **Actions → Build FIT70 APK → Run workflow** (it also runs on every push to `main`).
3. When it turns green, open the run and download the artifact **FIT70-debug-apk**, unzip it and install `app-debug.apk`.

Local build: Java 17 + Android SDK + Gradle 8.9, then `gradle assembleDebug`.

## What's new in 8.2
- **Goal timeline**: choose how many weeks (4-52) to reach your goal weight; the daily calorie target is computed from it and capped at a safe pace, with a warning and a realistic time if your goal is too fast. Home shows progress, weeks left, weekly rate and whether you are on track.
- Creative **Home**: calorie ring, goal journey, next meal and today's workout, quick actions, tap-to-fill water glasses, daily tip, streak flame.
- **One workout alarm** (training days only) instead of one per exercise; old per-exercise alarms are cancelled automatically.
- Orange **I ate this** buttons, 🔄 **swap dish**, smooth screen and card animations. Manual step entry removed.

## What's new in 8.1
- **First-run setup** (name, optional photo, personal data) asked once; your data lives under the profile photo (top left). "FIT70 v8" top right.
- **Home = daily record**: calories left (from your food diary), step counter (phone sensor, with manual add), water, weight.
- **13 real dishes with cooking steps** (pasta e ceci, riso e lenticchie, nasello al forno...) scaled to your calories; "I ate this" adds a dish to your diary.
- **Budget slider 20-70 EUR per week**; 35 groceries.
- **Shopping list**: add your own items, **share/save to your phone** (any app), save lists inside the app.

## What's new in 8.0 (full rebuild of the core)
- Rebuilt from scratch: correct meal names and portions (the old planner showed single letters), fixed status-bar overlap on Android.
- **Budget-aware meal plan**: set a weekly food budget; the planner picks cheaper foods to fit it and warns if the budget is too low for the calorie goal.
- **Weekly shopping list** with quantities, check-off, prices, and a **weekly shopping-day reminder**.
- **Store comparison** for 11 Italian chains (Eurospin, Lidl, In's, Aldi, MD, Penny, Todis, Carrefour, Esselunga, Conad, Coop). Chain price levels come from Altroconsumo's 2026 survey; item prices are estimates you can overwrite with your receipt price.

## What's new in 7.0
- **Fasting-end alarm**: starting a fast schedules an exact alarm for when it completes; ending the fast cancels it.
- **My food photos**: Tools tab, pick a food, take or choose a photo; it replaces that tile's picture in the food diary (included in backups).
- **Sleep & mood tracker** with a 7-day chart and average sleep.
- **App icon** added. A real grilled-chicken photo ships for the chicken tile.

## What's new in 6.0
- **Professional look**: refined glass tab bar, gradient buttons, safe-area support, **light and dark themes**, 5 accent colours.
- **🧰 Tools tab**: weekly report with 7-day calorie chart and estimated goal date; workout log with personal records; intermittent-fasting timer (12-20 h); body measurements with change tracking; your own custom foods; backup and restore as text.

## Also in 5.0
- **Pro tab**: a separate alarm for every meal (5) and every exercise, with on/off and time. Exercise alarms ring only on training days.
- Exact alarms (alarm sound, vibration), re-armed after reboot, app update or timezone change. On Android 12+ allow "Alarms & reminders" when asked.
- Food diary with 14 foods, photo tiles, calorie ring and protein/carbs/fat targets.
- Rest timer (30/60/90 s) with beep and vibration, workout streak, badges, weight trend chart.

## Real food photos
Tiles use illustrated art by default. To use real photos, add JPGs named `app/src/main/assets/www/img/food-<id>.jpg` (ids: egg, oat, yog, chk, ric, sal, fsh, bean, pas, brd, fru, nut, tun, shk). They are picked up automatically.

## Notes
Estimates are educational, not medical advice. Debug APK is for personal install, not Google Play.

---
# FIT70 5.0 (عربي)
1. أنشئ مستودعاً على GitHub وارفع **محتويات** الملف المضغوط (وليس الملف نفسه).
2. من تبويب Actions شغّل Build FIT70 APK.
3. نزّل FIT70-debug-apk وثبّت app-debug.apk.
تبويب **Pro**: تنبيه لكل وجبة ولكل تمرين، سجل طعام بصور، مؤقت راحة، سلسلة أيام، أوسمة ومنحنى وزن.
